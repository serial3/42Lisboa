#include<unistd.h>

void	ft_putnbr( int nb);

int	main( void )
{
	ft_putnbr(100);
	return (0);
}
