void	ft_print_combn( int nb);

int	main( void )
{
	ft_print_combn(3);
	return (0);
}
